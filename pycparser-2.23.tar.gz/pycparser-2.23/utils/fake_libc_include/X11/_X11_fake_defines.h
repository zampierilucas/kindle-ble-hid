#ifndef _X11_FAKE_DEFINES_H
#define _X11_FAKE_DEFINES_H

#define Atom CARD32
#define Bool int
#define KeySym CARD32
#define Pixmap CARD32
#define Time CARD32
#define _XFUNCPROTOBEGIN
#define _XFUNCPROTOEND
#define _Xconst const

#define _X_RESTRICT_KYWD
#define Cardinal unsigned int
#define Boolean int
#endif
